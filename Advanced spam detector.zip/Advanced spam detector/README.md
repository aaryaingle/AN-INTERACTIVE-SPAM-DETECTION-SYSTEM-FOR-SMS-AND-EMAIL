# Advanced Spam Detector

A Streamlit-based application for detecting spam messages and emails using AI and keyword analysis.

## 🚀 Quick Start

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)

### Installation

1. **Download or clone the project**
   ```bash
   git clone <your-repo-url>
   cd spam_detector

## Install dependencies

pip install -r requirements.txt

## how to run 

streamlit run Detector.py