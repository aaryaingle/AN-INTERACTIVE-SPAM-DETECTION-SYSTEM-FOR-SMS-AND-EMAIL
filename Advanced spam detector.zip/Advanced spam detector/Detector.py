# Detector.py
import streamlit as st
import numpy as np
import gensim.downloader as api
import re
import pandas as pd
import os
import datetime
import imaplib
import email
from email.header import decode_header
import ssl
import math

# ---------------------------
# 1. PAGE CONFIG
# ---------------------------
st.set_page_config(
    page_title="Advanced Spam Detector",
    page_icon=":shield:",
    layout="wide"
)

# ---------------------------
# 2. TEXT PROCESSING
# ---------------------------
def clean_text(text):
    text = text.lower()
    text = re.sub(r"[^a-z\s]", "", text)
    return text.strip()

def text_to_embeddings(text, glove):
    words = text.split()
    vectors = [glove[word] for word in words if word in glove]
    return np.mean(vectors, axis=0) if vectors else np.zeros(glove.vector_size)

# ---------------------------
# 3. SPAM WORDS MANAGEMENT 
# ---------------------------
DEFAULT_SPAM_WORDS = [
    # Financial spam
    "win", "prize", "lottery", "jackpot", "million", "billion", 
    "cash", "money", "reward", "fortune", "rich", "wealth",
    
    # Urgency and pressure
    "urgent", "immediate", "instant", "quick", "fast", "now",
    "limited", "expire", "deadline", "last chance", "final",
    
    # Suspicious actions
    "click", "claim", "verify", "confirm", "update", "secure",
    "suspend", "restrict", "locked", "hacked", "compromised",
    
    # Too-good-to-be-true offers
    "free", "discount", "offer", "deal", "bonus", "gift",
    "complimentary", "no cost", "zero cost", "special promotion",
    
    # Phishing indicators
    "password", "login", "credentials", "bank", "paypal", "account",
    "social security", "credit card", "ssn", "pin", "verification"
]

def load_spam_words():
    if os.path.exists("spam_words.csv"):
        try:
            df = pd.read_csv("spam_words.csv")
            return list(df['spam_words']) if 'spam_words' in df.columns else DEFAULT_SPAM_WORDS
        except:
            return DEFAULT_SPAM_WORDS
    return DEFAULT_SPAM_WORDS

def save_spam_words(spam_words_list):
    df = pd.DataFrame({'spam_words': spam_words_list})
    df.to_csv("spam_words.csv", index=False)

def get_spam_keywords(text, spam_words):
    return [word for word in text.split() if word in spam_words]

def is_legitimate_sender(text):
    """Check if the message comes from a legitimate source"""
    text_lower = text.lower()
    
    # List of legitimate domains and senders
    legitimate_senders = [
        'google', 'gmail', 'microsoft', 'outlook', 'apple', 'icloud',
        'amazon', 'facebook', 'twitter', 'linkedin', 'github',
        'paypal', 'bank', 'credit union', 'government', 'official'
    ]
    
    # Check for legitimate sender patterns
    sender_indicators = [sender for sender in legitimate_senders if sender in text_lower]
    
    return len(sender_indicators) > 0

# ---------------------------
# 4. SPAM DETECTION ENGINE (NO RANDOM FOREST)
# ---------------------------
def calculate_spam_score(text, spam_words, glove):
    """
    Calculate spam probability without Random Forest
    Uses word embeddings similarity and spam word matching
    """
    cleaned_text = clean_text(text)
    words = cleaned_text.split()
    
    if not words:
        return 0.0, []
    
    # Base score from spam word matching
    matched_keywords = get_spam_keywords(cleaned_text, spam_words)
    keyword_score = min(len(matched_keywords) * 0.15, 0.6)  # Max 60% from keywords
    
    # Calculate embedding-based score
    embedding_score = 0.0
    try:
        # Get text embedding
        text_embedding = text_to_embeddings(cleaned_text, glove)
        
        # Define spam reference vectors (common spam patterns)
        spam_reference_words = [
            "win", "free", "money", "urgent", "prize", "cash",
            "discount", "offer", "click", "claim", "verify"
        ]
        
        # Calculate similarity to spam reference words
        spam_similarities = []
        for spam_word in spam_reference_words:
            if spam_word in glove:
                spam_vec = glove[spam_word]
                similarity = np.dot(text_embedding, spam_vec) / (
                    np.linalg.norm(text_embedding) * np.linalg.norm(spam_vec) + 1e-8
                )
                spam_similarities.append(max(0, similarity))
        
        if spam_similarities:
            embedding_score = np.mean(spam_similarities) * 0.4  # Max 40% from embeddings
    except:
        embedding_score = 0.0
    
    # Text length factor (shorter messages more likely to be spam)
    length_factor = max(0, 1 - len(words) / 100) * 0.1  # Max 10% from length
    
    # Combine scores
    total_score = keyword_score + embedding_score + length_factor
    
    # Additional pattern-based adjustments
    text_lower = text.lower()
    
    # Financial indicators
    if any(char in text_lower for char in ['$', '€', '£', '₹']):
        total_score = min(total_score + 0.15, 1.0)
    
    # Prize/winning indicators
    prize_terms = ['won', 'winner', 'prize', 'award', 'lottery', 'jackpot']
    if any(term in text_lower for term in prize_terms):
        total_score = min(total_score + 0.1, 1.0)
    
    # Urgency indicators
    urgency_terms = ['claim now', 'act fast', 'immediately', 'limited time', 'expiring']
    if any(term in text_lower for term in urgency_terms):
        total_score = min(total_score + 0.1, 1.0)
    
    # Legitimate sender discount
    if is_legitimate_sender(text):
        total_score *= 0.6
    
    # Security notification discount
    if ('2-step verification' in text_lower or 'two-factor' in text_lower) and \
       ('google' in text_lower or 'security' in text_lower):
        total_score *= 0.4
    
    return min(total_score, 1.0), matched_keywords

# ---------------------------
# 5. EMAIL FETCHING FUNCTIONS
# ---------------------------
def fetch_emails(email_address, password, folder="INBOX", limit=10):
    """
    Fetch emails from Gmail using IMAP
    Returns: List of dictionaries with email data
    """
    emails = []
    
    try:
        # Create SSL context
        context = ssl.create_default_context()
        
        # Connect to Gmail IMAP server
        with imaplib.IMAP4_SSL("imap.gmail.com", 993, ssl_context=context) as mail:
            # Login to account
            mail.login(email_address, password)
            
            # Select mailbox folder
            mail.select(folder)
            
            # Search for all emails
            status, messages = mail.search(None, 'ALL')
            
            if status == 'OK':
                email_ids = messages[0].split()
                
                # Get most recent emails (limit)
                for email_id in email_ids[-limit:]:
                    # Fetch email
                    status, msg_data = mail.fetch(email_id, '(RFC822)')
                    
                    if status == 'OK':
                        raw_email = msg_data[0][1]
                        msg = email.message_from_bytes(raw_email)
                        
                        # Extract email details
                        email_info = extract_email_info(msg, email_id)
                        emails.append(email_info)
            
            # Logout
            mail.logout()
            
    except Exception as e:
        st.error(f"Error fetching emails: {str(e)}")
        return None
    
    return emails

def extract_email_info(msg, email_id):
    """Extract relevant information from email message"""
    # Decode subject
    subject, encoding = decode_header(msg["Subject"])[0] if msg["Subject"] else ("No Subject", None)
    if isinstance(subject, bytes):
        subject = subject.decode(encoding if encoding else "utf-8")
    
    # Get sender
    sender = msg.get("From", "Unknown")
    
    # Get date
    date = msg.get("Date", "Unknown")
    
    # Extract body text
    body = ""
    if msg.is_multipart():
        for part in msg.walk():
            content_type = part.get_content_type()
            content_disposition = str(part.get("Content-Disposition"))
            
            if content_type == "text/plain" and "attachment" not in content_disposition:
                try:
                    body = part.get_payload(decode=True).decode()
                    break
                except:
                    continue
    else:
        try:
            body = msg.get_payload(decode=True).decode()
        except:
            body = "Could not decode email content"
    
    return {
        'id': email_id.decode(),
        'subject': subject,
        'sender': sender,
        'date': date,
        'body': body[:500] + "..." if len(body) > 500 else body,
        'full_body': body
    }

# ---------------------------
# 6. FEEDBACK SYSTEM
# ---------------------------
def ensure_directory_exists():
    os.makedirs("data", exist_ok=True)

def record_feedback(message, message_type, prediction, confidence, feedback, correction, keywords, notes=None):
    ensure_directory_exists()
    feedback_file = "data/spam_feedback.csv"
    
    data = {
        "timestamp": datetime.datetime.now().isoformat(),
        "message": message,
        "message_type": message_type,
        "prediction": "spam" if prediction == 1 else "ham",
        "confidence": confidence,
        "feedback": feedback,
        "correction": correction,
        "matched_keywords": ", ".join(keywords) if keywords else "",
        "notes": notes
    }
    
    df = pd.DataFrame([data])
    
    try:
        if os.path.exists(feedback_file):
            df.to_csv(feedback_file, mode='a', header=False, index=False)
        else:
            df.to_csv(feedback_file, index=False)
        return True
    except Exception as e:
        st.error(f"Error saving feedback: {str(e)}")
        return False

def delete_feedback_records(records_to_delete=None):
    """Delete feedback records - either all or specific records"""
    feedback_file = "data/spam_feedback.csv"
    
    try:
        if not os.path.exists(feedback_file):
            return True
        
        if records_to_delete is None:
            os.remove(feedback_file)
            return True
        else:
            df = pd.read_csv(feedback_file)
            df = df[~df.index.isin(records_to_delete)]
            df.to_csv(feedback_file, index=False)
            return True
            
    except Exception as e:
        st.error(f"Error deleting records: {str(e)}")
        return False

# ---------------------------
# 7. PERFORMANCE METRICS FUNCTIONS (UPDATED)
# ---------------------------
def calculate_metrics():
    """Calculate performance metrics from ALL feedback data"""
    try:
        feedback_file = "data/spam_feedback.csv"
        if os.path.exists(feedback_file):
            df = pd.read_csv(feedback_file)
            
            if len(df) > 0:
                # Count correct and incorrect predictions
                correct_predictions = len(df[df['feedback'] == 'Yes'])
                incorrect_predictions = len(df[df['feedback'] == 'No'])
                total_feedback = len(df)
                
                # Calculate accuracy
                accuracy = correct_predictions / total_feedback if total_feedback > 0 else 0
                
                # For confusion matrix, we need to analyze the "No" feedback cases
                tp = tn = fp = fn = 0
                
                if incorrect_predictions > 0:
                    for _, row in df[df['feedback'] == 'No'].iterrows():
                        # For incorrect predictions, analyze what went wrong
                        predicted_spam = (row['prediction'] == 'spam')
                        actual_spam = (row['correction'] == 'Spam')
                        
                        if predicted_spam and actual_spam:
                            tp += 1  # True Positive (but user said it was wrong? This shouldn't happen)
                        elif not predicted_spam and not actual_spam:
                            tn += 1  # True Negative (but user said it was wrong? This shouldn't happen)
                        elif predicted_spam and not actual_spam:
                            fp += 1  # False Positive (model said spam, but it was actually ham)
                        elif not predicted_spam and actual_spam:
                            fn += 1  # False Negative (model said ham, but it was actually spam)
                
                # For correct predictions, we can infer TP and TN
                for _, row in df[df['feedback'] == 'Yes'].iterrows():
                    if row['prediction'] == 'spam':
                        tp += 1  # True Positive (model correctly identified spam)
                    else:
                        tn += 1  # True Negative (model correctly identified ham)
                
                # Calculate precision, recall, F1
                precision = tp / (tp + fp) if (tp + fp) > 0 else 0
                recall = tp / (tp + fn) if (tp + fn) > 0 else 0
                f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
                
                return {
                    'tp': tp, 'tn': tn, 'fp': fp, 'fn': fn,
                    'accuracy': accuracy, 'precision': precision,
                    'recall': recall, 'f1': f1,
                    'total_feedback': total_feedback,
                    'correct_predictions': correct_predictions,
                    'incorrect_predictions': incorrect_predictions
                }
    except Exception as e:
        st.error(f"Error calculating metrics: {str(e)}")
    
    return {
        'tp': 0, 'tn': 0, 'fp': 0, 'fn': 0,
        'accuracy': 0, 'precision': 0, 'recall': 0, 'f1': 0,
        'total_feedback': 0,
        'correct_predictions': 0,
        'incorrect_predictions': 0
    }
# ---------------------------
# 8. LOAD MODELS (ONLY GLOVE NOW)
# ---------------------------
@st.cache_resource
def load_glove_model():
    """Load only the GloVe model"""
    try:
        return api.load("glove-wiki-gigaword-100")
    except Exception as e:
        st.error(f"Error loading GloVe model: {str(e)}")
        return None

glove = load_glove_model()
spam_words = load_spam_words()

# ---------------------------
# 9. STREAMLIT UI (MAIN APPLICATION)
# ---------------------------
st.title("📩 Advanced Spam Detector")

# Initialize session state variables
if 'show_guide' not in st.session_state:
    st.session_state.show_guide = False
if 'auto_filled' not in st.session_state:
    st.session_state.auto_filled = False
if 'fetched_emails' not in st.session_state:
    st.session_state.fetched_emails = None
if 'email_options' not in st.session_state:
    st.session_state.email_options = None
if 'last_result' not in st.session_state:
    st.session_state.last_result = None
if 'selected_records' not in st.session_state:
    st.session_state.selected_records = []

# Check if GloVe model loaded successfully
if glove is None:
    st.error("❌ Failed to load GloVe model. Please check your internet connection and try again.")
    st.stop()

# Create main columns for layout
main_col1, main_col2 = st.columns([2, 1])

with main_col1:
    # Admin Panel
    with st.sidebar:
        st.header("Admin Panel")
        
        with st.expander("Manage Spam Words", expanded=True):
            st.info(f"Currently {len(spam_words)} spam words in database")
            
            if spam_words:
                st.write("Current spam words:")
                df_display = pd.DataFrame(spam_words, columns=["Spam Words"])
                st.dataframe(df_display, use_container_width=True, hide_index=True)
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("Add New Word")
                new_word = st.text_input("Enter a new spam word:", key="new_word_input")
                if st.button("Add Word", key="add_word_btn") and new_word:
                    if new_word not in spam_words:
                        spam_words.append(new_word)
                        save_spam_words(spam_words)
                        st.success(f"Added '{new_word}' to spam list!")
                        st.rerun()
                    else:
                        st.warning("This word is already in the spam list.")
            
            with col2:
                st.subheader("Remove Word")
                if spam_words:
                    word_to_remove = st.selectbox("Select a word to remove:", spam_words, key="remove_word_select")
                    if st.button("Remove Word", key="remove_word_btn"):
                        spam_words.remove(word_to_remove)
                        save_spam_words(spam_words)
                        st.success(f"Removed '{word_to_remove}' from spam list!")
                        st.rerun()
                else:
                    st.info("No words to remove.")
            
            st.subheader("Reset Options")
            if st.button("Reset to Default Words", key="reset_words_btn"):
                spam_words = DEFAULT_SPAM_WORDS.copy()
                save_spam_words(spam_words)
                st.success("Reset to default spam words successful!")
                st.rerun()
            
            st.subheader("CSV Import (Optional)")
            uploaded_file = st.file_uploader("Upload CSV with spam words", type=['csv'], key="csv_uploader")
            if uploaded_file:
                try:
                    df = pd.read_csv(uploaded_file)
                    if 'spam_words' in df.columns:
                        spam_words = list(df['spam_words'])
                        save_spam_words(spam_words)
                        st.success("Spam words updated from CSV!")
                        st.rerun()
                    else:
                        st.warning("CSV must contain 'spam_words' column")
                except Exception as e:
                    st.error(f"Error: {str(e)}")

        # Feedback data view with delete functionality
        if st.checkbox("View Feedback Data", key="view_feedback"):
            try:
                feedback_file = "data/spam_feedback.csv"
                if os.path.exists(feedback_file):
                    feedback_df = pd.read_csv(feedback_file)
                    
                    st.dataframe(feedback_df)
                    
                    st.subheader("🗑️ Delete Records")
                    
                    if st.button("❌ Delete All Records", key="delete_all_btn"):
                        if delete_feedback_records():
                            st.success("All feedback records deleted successfully!")
                            st.rerun()
                        else:
                            st.error("Failed to delete records.")
                    
                    st.write("Or select specific records to delete:")
                    record_indices = st.multiselect(
                        "Select records to delete:",
                        options=range(len(feedback_df)),
                        format_func=lambda x: f"Record {x+1} - {feedback_df.iloc[x]['prediction']} -> {feedback_df.iloc[x].get('correction', 'N/A')}"
                    )
                    
                    if record_indices and st.button("🗑️ Delete Selected Records", key="delete_selected_btn"):
                        if delete_feedback_records(record_indices):
                            st.success(f"Deleted {len(record_indices)} records successfully!")
                            st.rerun()
                        else:
                            st.error("Failed to delete selected records.")
                    
                    st.download_button("Download Feedback", feedback_df.to_csv(index=False), "spam_feedback_export.csv")
                else:
                    st.info("No feedback data yet")
            except Exception as e:
                st.error(f"Error loading feedback data: {str(e)}")

    # Message Type Selection
    st.header("🔍 Analyze Message")
    message_type = st.radio("Select message type:", ("SMS", "Email"), horizontal=True, key="msg_type_radio")

    # Email Configuration Section
    if message_type == "Email":
        st.header("📧 Email Configuration")
        
        col1, col2 = st.columns([2, 1])

        with col1:
            with st.expander("Configure Email Access", expanded=True):
                st.warning("🔐 Use App Password, not your real Gmail password!")
                
                if st.button("📋 How to Create App Password", key="guide_btn_main"):
                    st.session_state.show_guide = True
                
                email_address = st.text_input("Gmail Address", key="email_input_main")
                app_password = st.text_input("App Password", type="password", key="password_input_main")
                
                if st.button("Test Connection", key="test_btn_main"):
                    if email_address and app_password:
                        try:
                            context = ssl.create_default_context()
                            with imaplib.IMAP4_SSL("imap.gmail.com", 993, ssl_context=context) as mail:
                                mail.login(email_address, app_password)
                                st.success("✅ Connection successful!")
                                mail.logout()
                        except Exception as e:
                            st.error(f"❌ Connection failed: {str(e)}")
                    else:
                        st.warning("Please enter both email and app password")

        with col2:
            with st.expander("🔒 Security Info", expanded=True):
                st.info("""
                **Security Features:**
                - No email data is stored
                - SSL encrypted connections
                - App passwords only
                - In-memory processing
                - Your data remains private
                """)

        # App Password Guide
        if st.session_state.get('show_guide', False):
            st.header("🔐 Step-by-Step Guide: Creating Gmail App Password")
            
            with st.expander("Click to view detailed instructions", expanded=True):
                st.markdown("""
                ## 📋 How to Create a Gmail App Password
                Follow these steps to generate a secure app password...
                ### Step 1: Enable 2-Factor Authentication
                1. Go to your [Google Account](https://myaccount.google.com)
                2. Click on *Security* in the left sidebar
                3. Under "How you sign in to Google", find *2-Step Verification*
                4. Click *Get started* and follow the prompts to enable it
               
                ### Step 2: Generate App Password
                1. Go back to [Google Account Security](https://myaccount.google.com/security)
                2. Scroll down to *"How you sign in to Google"* section
                3. Click on *2-Step Verification* (you may need to sign in again)
                4. Scroll down to the bottom and find *"App passwords"*
                5. Click on *App passwords*
               
                ### Step 3: Create New App Password
                1. You may be asked to enter your Google password again
                2. Under *"Select app", choose **"Mail"*
                3. Under *"Select device", choose **"Other"* and name it "Spam Detector"
                4. Click *Generate*
               
                ### Step 4: Copy the Password
                1. A 16-character password will appear (e.g., abcd efgh ijkl mnop)
                2. *Copy this password exactly* (without spaces)
                3. Use this password in the Email Configuration section
               
                ### ⚠ Important Notes:
                - *Never use your real Gmail password*
                - The app password will look like: abcdefghijklmop
                 - You can delete app passwords anytime from your Google Account
                - Each app password is specific to one application
                - App passwords are more secure than your main password
               
                ### 🔒 Security Tips:
                - Don't share your app password with anyone
                - Delete unused app passwords
                - Use different app passwords for different applications
                - Regularly review your app passwords in Google Account
                """)
               
                if st.button("Close Guide", key="close_guide_btn"):
                    st.session_state.show_guide = False

        # Email Fetching Section
        st.header("📥 Fetch Emails")

        with st.expander("Fetch Emails from Gmail", expanded=True):
            if 'email_address' in locals() and 'app_password' in locals():
                if st.button("Fetch Recent Emails", key="fetch_btn_main"):
                    if email_address and app_password:
                        with st.spinner("Fetching emails..."):
                            emails = fetch_emails(email_address, app_password, limit=15)
                            
                            if emails:
                                st.success(f"✅ Fetched {len(emails)} emails")
                                st.session_state.fetched_emails = emails
                                email_options = [
                                    f"{email['subject'][:50]}... - From: {email['sender'][:30]}..." 
                                    for email in emails
                                ]
                                st.session_state.email_options = email_options
                            else:
                                st.error("No emails found or error fetching emails")
                    else:
                        st.warning("⚠️ Please configure email settings above first")
            else:
                st.info("👆 Configure your Gmail settings above to fetch emails")

        # Email Selection Dropdown
        if hasattr(st.session_state, 'fetched_emails') and st.session_state.fetched_emails:
            st.header("📨 Select Email to Analyze")
            
            selected_email_index = st.selectbox(
                "Choose an email to analyze:",
                range(len(st.session_state.fetched_emails)),
                format_func=lambda x: st.session_state.email_options[x],
                key="email_dropdown"
            )
            
            if selected_email_index is not None:
                selected_email = st.session_state.fetched_emails[selected_email_index]
                
                st.subheader("📧 Email Details")
                col1, col2 = st.columns(2)
                
                with col1:
                    st.write(f"**Subject:** {selected_email['subject']}")
                    st.write(f"**From:** {selected_email['sender']}")
                    st.write(f"**Date:** {selected_email['date']}")
                
                with col2:
                    if st.button("📋 Load this Email for Analysis", key="load_email_btn"):
                        st.session_state.auto_filled = True
                        st.session_state.auto_message = selected_email['full_body']
                        st.success("✅ Email loaded! Scroll down to analyze it.")
                
                st.subheader("📄 Email Content Preview")
                st.text_area("Email Body", selected_email['full_body'], height=200, key="email_preview", disabled=True)

    # Message Input Section
    st.header("📝 Enter Message")

    if hasattr(st.session_state, 'auto_filled') and st.session_state.auto_filled:
        user_input = st.text_area("Message to analyze:", value=st.session_state.auto_message, height=200, key="auto_text_area")
    else:
        user_input = st.text_area("Paste your message here:", height=200, key="manual_text_area")

    if st.button("Check Spam", type="primary", key="check_spam_btn"):
        if not user_input.strip():
            st.warning("Please enter a message first.")
        else:
            try:
                # Use the new spam detection function (no Random Forest)
                spam_probability, matched_keywords = calculate_spam_score(user_input, spam_words, glove)
                
                threshold = 0.5
                if spam_probability >= threshold:
                    prediction = 1
                    if spam_probability > 0.8:
                        st.error(f"🚨 HIGH CONFIDENCE SPAM (confidence: {spam_probability:.1%})")
                    else:
                        st.warning(f"⚠️ POTENTIAL SPAM (confidence: {spam_probability:.1%})")
                else:
                    prediction = 0
                    if spam_probability < 0.2:
                        st.success(f"✅ DEFINITELY NOT SPAM (confidence: {(1-spam_probability):.1%})")
                    else:
                        st.info(f"🔍 LIKELY NOT SPAM (confidence: {(1-spam_probability):.1%})")

                if matched_keywords:
                    st.write("⚠ Matched spam words:", ", ".join(matched_keywords))

                # Save results in session state
                st.session_state["last_result"] = {
                    "message": user_input,
                    "message_type": message_type,
                    "prediction": prediction,
                    "confidence": spam_probability,
                    "keywords": matched_keywords
                }

            except Exception as e:
                st.error(f"Error processing message: {str(e)}")
                st.info("Please try again.")

    # Feedback Section - FIXED: Check if last_result exists and is not None
    if "last_result" in st.session_state and st.session_state.last_result is not None:
        st.header("📝 Feedback")
        feedback = st.radio("Was this prediction correct?", ("Yes", "No"), horizontal=True, key="feedback_radio")

        if feedback == "No":
            correction = st.selectbox(
                "What should be the correct label?",
                ("Spam", "Not Spam"),
                key="correction_select"
            )
            additional_feedback = st.text_area(
                "Optional: Add more details about why this was incorrect",
                height=100,
                key="additional_feedback"
            )
        else:
            correction = "No correction needed"
            additional_feedback = None

        if st.button("Submit Feedback", key="feedback_btn"):
            r = st.session_state["last_result"]
            # ADDED SAFETY CHECK: Ensure r is not None
            if r is not None:
                success = record_feedback(
                    message=r["message"],
                    message_type=r["message_type"],
                    prediction=r["prediction"],
                    confidence=r["confidence"],
                    feedback=feedback,
                    correction=correction,
                    keywords=r["keywords"],
                    notes=additional_feedback
                )
                
                if success:
                    st.success("✅ Thank you for your feedback!")
                    st.balloons()
                    st.session_state.last_result = None  # Clear the result
                else:
                    st.error("❌ Failed to save feedback. Please try again.")
            else:
                st.error("No result data available. Please analyze a message first.")

# Performance Metrics Panel (Right Side)
with main_col2:
    st.header("📊 Performance Metrics")
    
    metrics = calculate_metrics()
    
    if metrics['total_feedback'] > 0:
        # Display basic stats first
        st.subheader("📈 Feedback Statistics")
        
        stat_col1, stat_col2, stat_col3 = st.columns(3)
        
        with stat_col1:
            st.metric("Total Feedback", metrics['total_feedback'])
        
        with stat_col2:
            st.metric("✅ Correct Predictions", metrics['correct_predictions'],
                     help="Number of times the model was right")
        
        with stat_col3:
            st.metric("❌ Incorrect Predictions", metrics['incorrect_predictions'],
                     help="Number of times the model was wrong")
        
        # Calculate accuracy percentage
        accuracy_percent = metrics['accuracy'] * 100
        
        st.progress(accuracy_percent / 100, text=f"Overall Accuracy: {accuracy_percent:.1f}%")
        
        st.divider()
        
        # Show confusion matrix and detailed metrics
        st.subheader("🎯 Performance Breakdown")
        
        if metrics['incorrect_predictions'] > 0:
            # We have some errors to analyze
            col1, col2 = st.columns(2)
            
            with col1:
                st.metric("✅ True Negative", metrics['tn'], 
                         help="Correctly identified as NOT spam")
                st.metric("❌ False Positive", metrics['fp'],
                         help="Incorrectly flagged as spam (False alarm)")
            
            with col2:
                st.metric("✅ True Positive", metrics['tp'],
                         help="Correctly identified as spam")
                st.metric("❌ False Negative", metrics['fn'],
                         help="Missed spam (Spam not detected)")
            
            st.divider()
            
            # Display accuracy metrics
            st.subheader("📊 Accuracy Metrics")
            
            accuracy_col1, accuracy_col2, accuracy_col3, accuracy_col4 = st.columns(4)
            
            with accuracy_col1:
                st.metric("Accuracy", f"{metrics['accuracy']:.1%}",
                         help="Overall correctness of predictions")
            
            with accuracy_col2:
                st.metric("Precision", f"{metrics['precision']:.1%}",
                         help="How many flagged emails are actually spam")
            
            with accuracy_col3:
                st.metric("Recall", f"{metrics['recall']:.1%}",
                         help="How many actual spam emails were detected")
            
            with accuracy_col4:
                st.metric("F1 Score", f"{metrics['f1']:.1%}",
                         help="Balance between precision and recall")
            
            # Performance interpretation
            st.divider()
            st.subheader("💡 Performance Interpretation")
            
            if metrics['accuracy'] > 0.9:
                st.success("🎉 Excellent performance! The model is very accurate.")
            elif metrics['accuracy'] > 0.8:
                st.info("👍 Good performance! The model is working well.")
            elif metrics['accuracy'] > 0.7:
                st.warning("⚠️ Fair performance. Consider reviewing spam words.")
            else:
                st.error("❌ Needs improvement. Check feedback for patterns.")
            
            # Specific recommendations
            if metrics['fp'] > metrics['fn']:
                st.info("💡 Recommendation: The model is being too aggressive. Consider adjusting spam word weights.")
            elif metrics['fn'] > metrics['fp']:
                st.info("💡 Recommendation: The model is missing some spam. Consider adding more spam words.")
                
        else:
            # All predictions were correct - show perfect performance
            st.success("🎯 Perfect Performance!")
            st.info("All predictions have been correct so far.")
            
            # Show what we correctly identified
            col1, col2 = st.columns(2)
            
            with col1:
                st.metric("✅ Spam Correctly Identified", metrics['tp'],
                         help="Number of spam messages correctly detected")
            
            with col2:
                st.metric("✅ Non-Spam Correctly Identified", metrics['tn'],
                         help="Number of legitimate messages correctly identified")
            
            st.divider()
            st.subheader("📊 Perfect Accuracy Metrics")
            
            perfect_col1, perfect_col2, perfect_col3, perfect_col4 = st.columns(4)
            
            with perfect_col1:
                st.metric("Accuracy", "100%", help="Perfect accuracy!")
            
            with perfect_col2:
                st.metric("Precision", "100%", help="All flagged messages were actually spam")
            
            with perfect_col3:
                st.metric("Recall", "100%", help="All spam messages were detected")
            
            with perfect_col4:
                st.metric("F1 Score", "100%", help="Perfect balance between precision and recall")
            
            st.success("🌟 Keep up the good work! Continue providing feedback to maintain this performance.")
        
    else:
        st.info("📋 No feedback data yet. Submit feedback to see performance metrics.")
        st.write("After analyzing messages and providing feedback, performance metrics will appear here.")
        
        # Placeholder metrics for demonstration
        st.subheader("📊 Example Metrics (with data)")
        st.write("Once you provide feedback, you'll see metrics like:")
        
        example_col1, example_col2 = st.columns(2)
        
        with example_col1:
            st.metric("✅ True Negative", "15", help="Correctly identified as NOT spam")
            st.metric("❌ False Positive", "2", help="Incorrectly flagged as spam")
        
        with example_col2:
            st.metric("✅ True Positive", "8", help="Correctly identified as spam")
            st.metric("❌ False Negative", "1", help="Missed spam")
        
        st.metric("Accuracy", "92.3%", help="Overall correctness")

    # Refresh button for metrics
    if st.button("🔄 Refresh Metrics", key="refresh_metrics"):
        st.rerun()
        
# Quick Analysis Tips
with st.expander("💡 Quick Analysis Tips", expanded=False):
    st.markdown("""
    **Tips for better spam detection:**
    - 🚨 **High spam indicators**: Urgent money requests, lottery wins, suspicious links
    - ✅ **Legitimate messages**: Security alerts from known companies
    - 🔍 **Check sender**: Verify email addresses and domains
    """)