{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 53,
   "id": "b1f184a6-d492-406b-88ce-275bfa962071",
   "metadata": {},
   "outputs": [],
   "source": [
    "#importing Libraries\n",
    "import pandas as pd\n",
    "import numpy as np\n",
    "import matplotlib.pyplot as plt\n",
    "import seaborn as sns\n",
    "import re\n",
    "import nltk"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 54,
   "id": "7ec4cdce-3a77-4930-9702-e95dc476e5c3",
   "metadata": {},
   "outputs": [],
   "source": [
    "from nltk.corpus import stopwords"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 55,
   "id": "b19ac554-6018-4e8b-8d3a-6b2483b377f1",
   "metadata": {},
   "outputs": [
    {
     "name": "stderr",
     "output_type": "stream",
     "text": [
      "[nltk_data] Downloading package stopwords to\n",
      "[nltk_data]     C:\\Users\\PURVA\\AppData\\Roaming\\nltk_data...\n",
      "[nltk_data]   Package stopwords is already up-to-date!\n"
     ]
    },
    {
     "data": {
      "text/plain": [
       "True"
      ]
     },
     "execution_count": 55,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "nltk.download('stopwords')"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 56,
   "id": "fdd736e5-a859-484b-baee-1587bc57cf35",
   "metadata": {},
   "outputs": [],
   "source": [
    "#Loading Datasets"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 57,
   "id": "ed078392-d51b-4986-a72a-24040ef81778",
   "metadata": {},
   "outputs": [],
   "source": [
    "data_sms = pd.read_csv(r\"C:\\Users\\PURVA\\OneDrive\\Desktop\\Datasets\\sms_spam.csv\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 58,
   "id": "0c5e304e-fc1d-4343-a906-6fb63a49410a",
   "metadata": {},
   "outputs": [],
   "source": [
    "data_email = pd.read_csv(r\"C:\\Users\\PURVA\\OneDrive\\Desktop\\Datasets\\email_spam.csv\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 59,
   "id": "bc0b4a5a-2acb-4d83-8557-95520cc4304e",
   "metadata": {},
   "outputs": [],
   "source": [
    "#Basic EDA"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 60,
   "id": "fa13769d-c3fe-4214-b919-9896b9482a9e",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "SMS Dataset:\n",
      "Series([], Name: count, dtype: int64)\n"
     ]
    }
   ],
   "source": [
    "print(\"SMS Dataset:\")\n",
    "print(data_sms['label'].value_counts())"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 61,
   "id": "47faf4da-04f5-49b9-8121-b114cd9febb0",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Email Dataset:\n",
      "label\n",
      "ham                                                                                             4941\n",
      "spam                                                                                            1785\n",
      " its termination would not  have such a phenomenal impact on the power situation .  however        1\n",
      " mr suresh prabhu                                                                                  1\n",
      "Name: count, dtype: int64\n"
     ]
    }
   ],
   "source": [
    "print(\"Email Dataset:\")\n",
    "print(data_email['label'].value_counts())"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 62,
   "id": "2f70e922-9ee7-473f-bdcb-8ae779bf68fb",
   "metadata": {},
   "outputs": [],
   "source": [
    "#Plotting fig"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 63,
   "id": "06d99557-0269-4e78-a5ba-de0c37c86f33",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "<Figure size 1000x500 with 0 Axes>"
      ]
     },
     "execution_count": 63,
     "metadata": {},
     "output_type": "execute_result"
    },
    {
     "data": {
      "text/plain": [
       "<Figure size 1000x500 with 0 Axes>"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "plt.figure(figsize=(10, 5))"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 64,
   "id": "1c617826-bce9-4976-ae69-c0b385155135",
   "metadata": {},
   "outputs": [],
   "source": [
    "data_sms = data_sms[[\"v1\", \"v2\"]]  \n",
    "data_sms.columns = [\"label\", \"message\"]  "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 65,
   "id": "675166fa-e319-415a-9f2f-3884db3cd9f1",
   "metadata": {},
   "outputs": [],
   "source": [
    "data_email = data_email[[\"label\", \"email_text\"]]  \n",
    "data_email.columns = [\"label\", \"message\"]  "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 69,
   "id": "0cfd610c-1686-48fe-b4de-e66d5dc08e89",
   "metadata": {},
   "outputs": [],
   "source": [
    "def clean_text(text):\n",
    "    text = re.sub(r'http\\S+|www\\S+|@\\w+|[^a-zA-Z]', ' ', text)\n",
    "    text = text.lower().strip()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 70,
   "id": "30e05352-ec32-4c9b-b924-5212c4a136c4",
   "metadata": {},
   "outputs": [],
   "source": [
    "data_sms = data_sms.assign(cleaned_text=lambda x: x['message'].apply(clean_text))"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 71,
   "id": "d768fe04-0c5a-40ce-a562-de705336e266",
   "metadata": {},
   "outputs": [],
   "source": [
    "data_email = data_email.assign(cleaned_text=lambda x: x['message'].apply(clean_text))"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 72,
   "id": "dd55768d-a5fb-44af-b53f-b4d3403d8b97",
   "metadata": {},
   "outputs": [],
   "source": [
    "data_sms.to_csv('cleaned_sms.csv', index=False)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 73,
   "id": "6a53a97a-ebec-4570-bcf4-49acd3ed5498",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Preprocessing done. Data saved.\n"
     ]
    }
   ],
   "source": [
    "data_email.to_csv('cleaned_email.csv', index=False)\n",
    "print(\"Preprocessing done. Data saved.\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 74,
   "id": "83df60f1-7086-4df1-b1d1-9468fe9d3ea7",
   "metadata": {},
   "outputs": [],
   "source": [
    "import gensim.downloader as api"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 75,
   "id": "417544c7-eb21-4688-85f8-61438f0c32ce",
   "metadata": {},
   "outputs": [],
   "source": [
    "glove = api.load(\"glove-wiki-gigaword-100\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 76,
   "id": "08171233-17d8-4a14-8f1c-9e4c6cfd6b1b",
   "metadata": {},
   "outputs": [],
   "source": [
    "def text_to_embeddings(text, embedding_model):\n",
    "    words = text.split()\n",
    "    embeddings = [embedding_model[word] for word in words if word in embedding_model]\n",
    "    return np.mean(embeddings, axis=0) if embeddings else np.zeros(100)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 77,
   "id": "ef98e793-5133-4798-99cb-c8fa8a7cd785",
   "metadata": {},
   "outputs": [],
   "source": [
    "def text_to_embeddings(text, embedding_model):\n",
    "    if not isinstance(text, str):\n",
    "        text = \"\"  # Replace None/NaN with empty string\n",
    "    words = text.split()\n",
    "    embeddings = [embedding_model[word] for word in words if word in embedding_model]\n",
    "    return np.mean(embeddings, axis=0) if embeddings else np.zeros(100)\n",
    "\n",
    "# Clean your DataFrame columns before running\n",
    "data_sms['cleaned_text'] = data_sms['cleaned_text'].fillna(\"\")\n",
    "data_email['cleaned_text'] = data_email['cleaned_text'].fillna(\"\")\n",
    "# Convert SMS texts to embeddings\n",
    "\n",
    "sms_embeddings = np.array([text_to_embeddings(text, glove) for text in data_sms['cleaned_text']])\n",
    "email_embeddings = np.array([text_to_embeddings(text, glove) for text in data_email['cleaned_text']])"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 78,
   "id": "f062f854-dc04-40c7-b6c9-bfbfbff93241",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Embeddings saved.\n"
     ]
    }
   ],
   "source": [
    "# Save embeddings\n",
    "np.save('sms_embeddings.npy', sms_embeddings)\n",
    "np.save('email_embeddings.npy', email_embeddings)\n",
    "print(\"Embeddings saved.\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 79,
   "id": "ece0c0eb-e40e-41dc-9a3d-34fdc19cad19",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Requirement already satisfied: catboost in c:\\users\\purva\\anaconda3\\lib\\site-packages (1.2.8)\n",
      "Requirement already satisfied: graphviz in c:\\users\\purva\\anaconda3\\lib\\site-packages (from catboost) (0.21)\n",
      "Requirement already satisfied: matplotlib in c:\\users\\purva\\anaconda3\\lib\\site-packages (from catboost) (3.9.2)\n",
      "Requirement already satisfied: numpy<3.0,>=1.16.0 in c:\\users\\purva\\anaconda3\\lib\\site-packages (from catboost) (1.26.4)\n",
      "Requirement already satisfied: pandas>=0.24 in c:\\users\\purva\\anaconda3\\lib\\site-packages (from catboost) (2.2.2)\n",
      "Requirement already satisfied: scipy in c:\\users\\purva\\anaconda3\\lib\\site-packages (from catboost) (1.13.1)\n",
      "Requirement already satisfied: plotly in c:\\users\\purva\\anaconda3\\lib\\site-packages (from catboost) (5.24.1)\n",
      "Requirement already satisfied: six in c:\\users\\purva\\anaconda3\\lib\\site-packages (from catboost) (1.16.0)\n",
      "Requirement already satisfied: python-dateutil>=2.8.2 in c:\\users\\purva\\anaconda3\\lib\\site-packages (from pandas>=0.24->catboost) (2.9.0.post0)\n",
      "Requirement already satisfied: pytz>=2020.1 in c:\\users\\purva\\anaconda3\\lib\\site-packages (from pandas>=0.24->catboost) (2024.1)\n",
      "Requirement already satisfied: tzdata>=2022.7 in c:\\users\\purva\\anaconda3\\lib\\site-packages (from pandas>=0.24->catboost) (2023.3)\n",
      "Requirement already satisfied: contourpy>=1.0.1 in c:\\users\\purva\\anaconda3\\lib\\site-packages (from matplotlib->catboost) (1.2.0)\n",
      "Requirement already satisfied: cycler>=0.10 in c:\\users\\purva\\anaconda3\\lib\\site-packages (from matplotlib->catboost) (0.11.0)\n",
      "Requirement already satisfied: fonttools>=4.22.0 in c:\\users\\purva\\anaconda3\\lib\\site-packages (from matplotlib->catboost) (4.51.0)\n",
      "Requirement already satisfied: kiwisolver>=1.3.1 in c:\\users\\purva\\anaconda3\\lib\\site-packages (from matplotlib->catboost) (1.4.4)\n",
      "Requirement already satisfied: packaging>=20.0 in c:\\users\\purva\\anaconda3\\lib\\site-packages (from matplotlib->catboost) (24.1)\n",
      "Requirement already satisfied: pillow>=8 in c:\\users\\purva\\anaconda3\\lib\\site-packages (from matplotlib->catboost) (10.4.0)\n",
      "Requirement already satisfied: pyparsing>=2.3.1 in c:\\users\\purva\\anaconda3\\lib\\site-packages (from matplotlib->catboost) (3.1.2)\n",
      "Requirement already satisfied: tenacity>=6.2.0 in c:\\users\\purva\\anaconda3\\lib\\site-packages (from plotly->catboost) (8.2.3)\n"
     ]
    }
   ],
   "source": [
    "!pip install catboost"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 80,
   "id": "d19b019d-c3a7-4367-abac-d83d40d907da",
   "metadata": {},
   "outputs": [],
   "source": [
    "from catboost import CatBoostClassifier"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 81,
   "id": "16a9a9d5-85a7-45ba-a67e-ca10d57e2ea8",
   "metadata": {},
   "outputs": [],
   "source": [
    "from sklearn.model_selection import train_test_split\n",
    "from sklearn.metrics import classification_report, confusion_matrix"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 82,
   "id": "a8364a32-4f30-4ae8-9906-4fa2f5793f02",
   "metadata": {},
   "outputs": [],
   "source": [
    "#Load embeddings"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 83,
   "id": "12f8aece-30a2-4f67-ab00-95ee5a130673",
   "metadata": {},
   "outputs": [],
   "source": [
    "X_sms = np.load('sms_embeddings.npy')\n",
    "y_sms = data_sms['label'].map({'ham': 0, 'spam': 1})  "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 84,
   "id": "309465b9-fe0f-46b5-b12b-ce88676b01fd",
   "metadata": {},
   "outputs": [],
   "source": [
    "X_email = np.load('email_embeddings.npy')\n",
    "y_email = data_email['label'].map({'ham': 0, 'spam': 1})  "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 85,
   "id": "8c551db9-d153-4531-ac09-54a8b8151ea9",
   "metadata": {},
   "outputs": [],
   "source": [
    "# Split data"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 86,
   "id": "1013cfba-351e-4c42-a8b4-f50a5a9cfcc6",
   "metadata": {},
   "outputs": [],
   "source": [
    "X_train_sms, X_test_sms, y_train_sms, y_test_sms = train_test_split(X_sms, y_sms, test_size=0.2)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 87,
   "id": "e06773ce-8de1-4e91-b283-fa5637c51e2e",
   "metadata": {},
   "outputs": [],
   "source": [
    "X_train_email, X_test_email, y_train_email, y_test_email = train_test_split(X_email, y_email, test_size=0.2)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 88,
   "id": "b9d47989-7be8-4fb6-b32c-82321e7b6a65",
   "metadata": {},
   "outputs": [],
   "source": [
    "X_train_sms += np.random.normal(0, 1e-6, X_train_sms.shape)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 89,
   "id": "6ac4b9bf-bb1b-41de-a319-3892253a966b",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Learning rate set to 0.114691\n",
      "0:\tlearn: 0.6191852\ttotal: 84.8ms\tremaining: 16.9s\n",
      "10:\tlearn: 0.3998528\ttotal: 1.01s\tremaining: 17.3s\n",
      "20:\tlearn: 0.3761874\ttotal: 1.94s\tremaining: 16.5s\n",
      "30:\tlearn: 0.3648919\ttotal: 2.91s\tremaining: 15.9s\n",
      "40:\tlearn: 0.3557949\ttotal: 3.97s\tremaining: 15.4s\n",
      "50:\tlearn: 0.3469621\ttotal: 4.92s\tremaining: 14.4s\n",
      "60:\tlearn: 0.3386112\ttotal: 5.82s\tremaining: 13.3s\n",
      "70:\tlearn: 0.3302892\ttotal: 6.74s\tremaining: 12.2s\n",
      "80:\tlearn: 0.3210627\ttotal: 7.58s\tremaining: 11.1s\n",
      "90:\tlearn: 0.3129170\ttotal: 8.53s\tremaining: 10.2s\n",
      "100:\tlearn: 0.3042332\ttotal: 9.38s\tremaining: 9.19s\n",
      "110:\tlearn: 0.2951263\ttotal: 10.2s\tremaining: 8.2s\n",
      "120:\tlearn: 0.2865300\ttotal: 11s\tremaining: 7.19s\n",
      "130:\tlearn: 0.2778699\ttotal: 11.8s\tremaining: 6.23s\n",
      "140:\tlearn: 0.2693651\ttotal: 12.6s\tremaining: 5.29s\n",
      "150:\tlearn: 0.2607744\ttotal: 13.4s\tremaining: 4.36s\n",
      "160:\tlearn: 0.2518262\ttotal: 14.2s\tremaining: 3.45s\n",
      "170:\tlearn: 0.2447202\ttotal: 15s\tremaining: 2.54s\n",
      "180:\tlearn: 0.2366903\ttotal: 15.8s\tremaining: 1.66s\n",
      "190:\tlearn: 0.2298411\ttotal: 16.6s\tremaining: 780ms\n",
      "199:\tlearn: 0.2229222\ttotal: 17.3s\tremaining: 0us\n"
     ]
    },
    {
     "data": {
      "text/plain": [
       "<catboost.core.CatBoostClassifier at 0x21017755c40>"
      ]
     },
     "execution_count": 89,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Train SMS model\n",
    "sms_model = CatBoostClassifier(iterations=200, verbose=10 , loss_function='Logloss')\n",
    "sms_model.fit(X_train_sms, y_train_sms)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 90,
   "id": "a6f2f8db-419a-470a-a17e-cc6387de07ff",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "SMS Model Report:\n",
      "              precision    recall  f1-score   support\n",
      "\n",
      "           0       0.86      1.00      0.93      1920\n",
      "           1       0.00      0.00      0.00       308\n",
      "\n",
      "    accuracy                           0.86      2228\n",
      "   macro avg       0.43      0.50      0.46      2228\n",
      "weighted avg       0.74      0.86      0.80      2228\n",
      "\n"
     ]
    },
    {
     "name": "stderr",
     "output_type": "stream",
     "text": [
      "C:\\Users\\PURVA\\anaconda3\\Lib\\site-packages\\sklearn\\metrics\\_classification.py:1531: UndefinedMetricWarning: Precision is ill-defined and being set to 0.0 in labels with no predicted samples. Use `zero_division` parameter to control this behavior.\n",
      "  _warn_prf(average, modifier, f\"{metric.capitalize()} is\", len(result))\n",
      "C:\\Users\\PURVA\\anaconda3\\Lib\\site-packages\\sklearn\\metrics\\_classification.py:1531: UndefinedMetricWarning: Precision is ill-defined and being set to 0.0 in labels with no predicted samples. Use `zero_division` parameter to control this behavior.\n",
      "  _warn_prf(average, modifier, f\"{metric.capitalize()} is\", len(result))\n",
      "C:\\Users\\PURVA\\anaconda3\\Lib\\site-packages\\sklearn\\metrics\\_classification.py:1531: UndefinedMetricWarning: Precision is ill-defined and being set to 0.0 in labels with no predicted samples. Use `zero_division` parameter to control this behavior.\n",
      "  _warn_prf(average, modifier, f\"{metric.capitalize()} is\", len(result))\n"
     ]
    }
   ],
   "source": [
    "print(\"SMS Model Report:\")\n",
    "print(classification_report(y_test_sms, sms_model.predict(X_test_sms)))"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 91,
   "id": "ecb44524-1f98-4f0f-b491-de86ad5af520",
   "metadata": {},
   "outputs": [],
   "source": [
    "X_train_email += np.random.normal(0, 1e-6, X_train_email.shape)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 92,
   "id": "f31e54ad-a0f0-4ad4-b96a-66485fab061b",
   "metadata": {},
   "outputs": [],
   "source": [
    "def clean(X, y):\n",
    "    mask = ~np.isnan(y)\n",
    "    return X[mask], y[mask]\n",
    "\n",
    "# 2. Train Email model\n",
    "X_train, y_train = clean(X_train_email, y_train_email)\n",
    "model = CatBoostClassifier(iterations=200, verbose=0).fit(X_train,y_train)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 93,
   "id": "ed9d45f5-5ef0-49e3-8112-ef4bb7cea1d7",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "              precision    recall  f1-score   support\n",
      "\n",
      "         0.0       0.75      1.00      0.85      1005\n",
      "         1.0       0.00      0.00      0.00       341\n",
      "\n",
      "    accuracy                           0.75      1346\n",
      "   macro avg       0.37      0.50      0.43      1346\n",
      "weighted avg       0.56      0.75      0.64      1346\n",
      "\n"
     ]
    },
    {
     "name": "stderr",
     "output_type": "stream",
     "text": [
      "C:\\Users\\PURVA\\anaconda3\\Lib\\site-packages\\sklearn\\metrics\\_classification.py:1531: UndefinedMetricWarning: Precision is ill-defined and being set to 0.0 in labels with no predicted samples. Use `zero_division` parameter to control this behavior.\n",
      "  _warn_prf(average, modifier, f\"{metric.capitalize()} is\", len(result))\n",
      "C:\\Users\\PURVA\\anaconda3\\Lib\\site-packages\\sklearn\\metrics\\_classification.py:1531: UndefinedMetricWarning: Precision is ill-defined and being set to 0.0 in labels with no predicted samples. Use `zero_division` parameter to control this behavior.\n",
      "  _warn_prf(average, modifier, f\"{metric.capitalize()} is\", len(result))\n",
      "C:\\Users\\PURVA\\anaconda3\\Lib\\site-packages\\sklearn\\metrics\\_classification.py:1531: UndefinedMetricWarning: Precision is ill-defined and being set to 0.0 in labels with no predicted samples. Use `zero_division` parameter to control this behavior.\n",
      "  _warn_prf(average, modifier, f\"{metric.capitalize()} is\", len(result))\n"
     ]
    }
   ],
   "source": [
    "# 3. Evaluate\n",
    "X_test, y_test = clean(X_test_email, y_test_email)\n",
    "print(classification_report(y_test, model.predict(X_test)))"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 39,
   "id": "4e71eaea-6b6b-4c5d-91a3-c605123dd5a4",
   "metadata": {},
   "outputs": [],
   "source": [
    "from keybert import KeyBERT"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 40,
   "id": "f53e0c51-dcf4-40b9-bd73-378394dcf480",
   "metadata": {},
   "outputs": [],
   "source": [
    "kw_model = KeyBERT()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 41,
   "id": "548aa090-fa1e-42e4-acf6-103f526fab2e",
   "metadata": {},
   "outputs": [],
   "source": [
    "def get_spam_keywords(text, top_n=5):\n",
    "    keywords = kw_model.extract_keywords(text, keyphrase_ngram_range=(1, 2), top_n=top_n)\n",
    "    return [kw[0] for kw in keywords]"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 42,
   "id": "9b7a0bd7-8632-46d8-bea9-cf1568018cac",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Spam Keywords: ['free prize', 'prize click', 'prize', 'win free', 'claim reward']\n"
     ]
    }
   ],
   "source": [
    "sample_spam = \"WIN FREE PRIZE! Click here to claim your reward now!\"\n",
    "print(\"Spam Keywords:\", get_spam_keywords(sample_spam))"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 43,
   "id": "931f7ebb-471a-4b42-a23b-4f4d3d66769d",
   "metadata": {},
   "outputs": [],
   "source": [
    "import streamlit as st\n",
    "import numpy as np\n",
    "import joblib"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 44,
   "id": "bd397e84-41b8-43e8-8400-ce58b473ca6c",
   "metadata": {},
   "outputs": [],
   "source": [
    "from joblib import dump"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 45,
   "id": "c4739677-1587-4bfb-90dc-55b106b0eb0e",
   "metadata": {},
   "outputs": [],
   "source": [
    "email_model = joblib.load('email_model.joblib')"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 46,
   "id": "43ed4c3b-8b19-45e4-915c-f54907276fc7",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "['email_model.joblib']"
      ]
     },
     "execution_count": 46,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "dump(email_model, 'email_model.joblib') "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 47,
   "id": "b0714cd0-b226-4e69-bb06-1dd5d17bfb54",
   "metadata": {},
   "outputs": [],
   "source": [
    "sms_model = joblib.load('sms_model.joblib')"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 48,
   "id": "252aec82-ae55-4ad8-bc34-919617b56ecb",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "['sms_model.joblib']"
      ]
     },
     "execution_count": 48,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "dump(sms_model, 'sms_model.joblib') "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 49,
   "id": "7ae287fd-85f5-4a55-9df3-b9c8383a40c2",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Email model exists: True\n",
      "SMS model exists: True\n"
     ]
    }
   ],
   "source": [
    "import os\n",
    "print(\"Email model exists:\", os.path.exists(\"email_model.joblib\"))\n",
    "print(\"SMS model exists:\", os.path.exists(\"sms_model.joblib\"))"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 50,
   "id": "6f4fd58f-919e-4ffd-877c-5dca6cd17e56",
   "metadata": {},
   "outputs": [],
   "source": [
    "def predict_message(text):\n",
    "    raw_probability = model.predict_proba([text])[0][1]\n",
    "    spam_probability = raw_probability\n",
    "    if spam_probability > 0.85:\n",
    "        return \"Spam\", spam_probability\n",
    "    else:\n",
    "        return \"Ham\", spam_probability"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 51,
   "id": "1019884f-2a73-4869-918b-9d74bd7dcd91",
   "metadata": {},
   "outputs": [
    {
     "name": "stderr",
     "output_type": "stream",
     "text": [
      "2025-08-20 12:32:02.449 \n",
      "  \u001b[33m\u001b[1mWarning:\u001b[0m to view this Streamlit app on a browser, run it with the following\n",
      "  command:\n",
      "\n",
      "    streamlit run C:\\Users\\PURVA\\anaconda3\\Lib\\site-packages\\ipykernel_launcher.py [ARGUMENTS]\n",
      "2025-08-20 12:32:02.457 Session state does not function when running a script without `streamlit run`\n"
     ]
    }
   ],
   "source": [
    "st.title(\"Spam Detecter\")\n",
    "message_type = st.radio(\"Select message type:\", (\"SMS\", \"Email\"))\n",
    "user_input = st.text_area(\"Paste your message here:\")\n",
    "\n",
    "if st.button(\"Check Spam\"):\n",
    "    cleaned_text = clean_text(user_input)\n",
    "    embedding = text_to_embeddings(cleaned_text, glove).reshape(1, -1)\n",
    "\n",
    "    if message_type == \"SMS\":\n",
    "        proba = sms_model.predict_proba(embedding)[0]\n",
    "    else:\n",
    "        proba = email_model.predict_proba(embedding)[0]\n",
    "\n",
    "    st.write(f\"spam Probability: {proba[1]:.2%}\")\n",
    "    st.write(\"Suspicious keywords:\", get_spam_keywords(cleaned_text))   "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 52,
   "id": "0a0a2aa0-b985-4dc1-b0ae-507c2a88b4ea",
   "metadata": {},
   "outputs": [],
   "source": [
    "data_spam = pd.read_csv(r\"C:\\Users\\PURVA\\OneDrive\\Desktop\\Datasets\\spam_words.csv\", encoding='latin-1') "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "d1e7396c-3877-4f8a-a0fc-0fa65586bb85",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python [conda env:base] *",
   "language": "python",
   "name": "conda-base-py"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.12.7"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
